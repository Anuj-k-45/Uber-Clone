import { Server } from "socket.io";
import userModel from "./models/user.model.js";
import captainModel from "./models/captain.model.js";

let io;

function initializeSocket(server) {
  io = new Server(server, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"],
    },
  });

  io.on("connection", (socket) => {
    console.log(`Client connected: ${socket.id}`);

    socket.on("join", async (data) => {
      const { userId, userType } = data;

      if (userType === "user") {
        const user = await userModel.findByIdAndUpdate(userId, {
          socketId: socket.id,
        });
        console.log(user);
      } else if (userType === "captain") {
        const captain = await captainModel.findByIdAndUpdate(userId, {
          socketId: socket.id,
        });
        console.log(captain);
      }
    });

    socket.on("update-location-captain", async (data) => {
      const { userId, location } = data;

      if (!location || !location.ltd || !location.lng) {
        return socket.emit("error", { message: "Invalid location data" });
      }

      await captainModel.findByIdAndUpdate(userId, {
        location: {
          ltd: location.ltd,
          lng: location.lng,
        },
      });
    });

    socket.on("disconnect", () => {
      console.log(`Client disconnected: ${socket.id}`);
    });
  });
}

const sendMessageToSocketId = (socketId, messageObject) => {
  if (io) {
    console.log(`📨 Sending message to socket ${socketId}:`, messageObject);
    io.to(socketId).emit(messageObject.type, messageObject.payload); // ✅ use type/payload
    console.log("Message sent successfully.");
  } else {
    console.log("Socket.io not initialized.");
  }
};


export { initializeSocket, sendMessageToSocketId };
